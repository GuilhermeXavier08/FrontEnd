const prompt = require("prompt-sync")();
let numero = Number(
  prompt("Informe um número e eu direi se é ímpar ou par!: ")
);
if (numero % 2 === 0) {
  console.log(`O número ${numero} é par!`);
} else {
  console.log(`O número ${numero} é ímpar!`);
}
